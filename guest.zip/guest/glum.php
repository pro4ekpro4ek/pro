<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';

$post = mysql_fetch_assoc(mysql_query("SELECT * FROM `guest` WHERE `id` = '".intval($_GET['post'])."' limit 1"));
$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
$page = intval($_GET['page']);

if (isset($_GET['ok']) && $_SESSION['img'] && $_SESSION['type'] && $_SESSION['pos'])
{
	mysql_query("INSERT INTO `guest_glum` (id_user, time, dir, img, margin_left, id_post) values('$user[id]', '$time', '".my_esc($_SESSION['type'])."', '".intval($_SESSION['img'])."', '".intval($_SESSION['pos'])."', '$post[id]')");
	
	if ($_SESSION['type'] == 'tomate')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], кинул".($user['pol'] == 0 ? "а" : "")." [red][b]Помидор[/b][/red] на ваш пост, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'kraski')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], заляпал".($user['pol'] == 0 ? "а" : "")." [red][b]Краской[/b][/red] ваш пост, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'puli')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], пальнул".($user['pol'] == 0 ? "а" : "")." [blue][b]Из Нагана[/b][/blue] по вашему посту, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'pchel')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], посадил".($user['pol'] == 0 ? "а" : "")." [green][b]Пчелку[/b][/green] на ваш пост, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'scelet')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], оставил".($user['pol'] == 0 ? "а" : "")." [blue][b]Скелет[/b][/blue] на вашем посту, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'dino')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], оставил".($user['pol'] == 0 ? "а" : "")." [green][b]След ДИНОЗАВРА[/b][/green] на вашем посту, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'kiss')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], оставил".($user['pol'] == 0 ? "а" : "")." [red][b]Поцелуйчик[/b][/red] на вашем посту, в [url=/guest/?page=$page]Гостевой[/url]";
	elseif ($_SESSION['type'] == 'serdce')
	$msg = "Пользователь [url=info.php?id=$user[id]][b]$user[nick][/b][/url], оставил".($user['pol'] == 0 ? "а" : "")." [red][b]Сердечко[/b][/red] на вашем посту, в [url=/guest/?page=$page]Гостевой[/url]";
	
	mysql_query("INSERT INTO `jurnal` (`id_user`, `id_kont`, `msg`, `time`) values('0', '$ank[id]', '". my_esc($msg) ."', '$time')");
	
	// Cписываем баллы
	mysql_query("UPDATE `user` SET `balls` = '".($user['balls'] - 20)."' WHERE `id` = '$user[id]'");
	
	$_SESSION['message'] = 'Ляп успешно оставлен';
	header("Location: index.php?page=" . $page);
	exit;
}

$set['title'] = 'Ляп на пост'; // заголовок страницы

include_once '../sys/inc/thead.php';
title();
aut();
if($user['balls']>=20){

/**
* / Стиль для постов
*/
?>
<style>
.n1 {
	background:#fff; 
	padding:4px; 
	margin:2px; 
	margin-top:5px; 
	display:table;
	border: 1px #cacaca solid;
	-o-border-radius: 9px 9px 0 0;
	border-radius:9px 9px 0 0;
	-moz-border-radius:9px 9px 0 0;
	
}

.n2 {
	background:#fff; 
	padding:4px; 
	margin:2px;
	margin-bottom:5px; 
	border: 1px #cacaca solid;
	-o-border-radius: 0 9px 9px 9px;
	border-radius: 0 9px 9px 9px;
	-moz-border-radius: 0 9px 9px 9px;
}
</style>
<?
	
	echo '<div class="nav1" style="background-image:url(style/' . $post['fon'] . '.jpg); padding-top:10px; ">';

	/**
	* 
	* @var / Выводим ляпы на пост
	* 
	*/
	$l = mysql_query("SELECT * FROM `guest_glum` WHERE `id_post` = '$post[id]'");
	
	while ($glum = mysql_fetch_assoc($l))
	{
		echo '<img src="img/' . $glum['dir'] . '/' . $glum['img'] . '.png" style="position: absolute; margin-left:' . $glum['margin_left'] . 'px;" />';
	}
	
	/**
	* 
	* @var / Cохраняем параметры ляпа в сессию
	* 
	*/
	if (isset($_GET['act']))
	{
		if ($_GET['act'] == 'pomidor')
		{	
			$_SESSION['type'] = 'tomate'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 4);
		}
		elseif ($_GET['act'] == 'kraski')
		{	
			$_SESSION['type'] = 'kraski'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 7);
		}
		elseif ($_GET['act'] == 'puli')
		{	
			$_SESSION['type'] = 'puli'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 5);
		}
		elseif ($_GET['act'] == 'pchel')
		{	
			$_SESSION['type'] = 'pchel'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 9);
		}
		elseif ($_GET['act'] == 'scelet')
		{	
			$_SESSION['type'] = 'scelet'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 9);
		}
		elseif ($_GET['act'] == 'dino')
		{	
			$_SESSION['type'] = 'dino'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 8);
		}
		elseif ($_GET['act'] == 'kiss')
		{	
			$_SESSION['type'] = 'kiss'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 9);
		}
		elseif ($_GET['act'] == 'serdce')
		{	
			$_SESSION['type'] = 'serdce'; 
			$_SESSION['pos'] = mt_rand(1, 176);
			$_SESSION['img'] = mt_rand(1, 12);
		}
				echo '<img src="img/' . $_SESSION['type'] . '/' . $_SESSION['img'] . '.png" style="position: absolute; margin-left:' . $_SESSION['pos'] . 'px;" />';		
	}
	
	echo '<div class="n1">';
	echo '<div style="position:relative;">';
	echo " <a href='/info.php?id=$ank[id]'>$ank[nick]</a> ";
	echo online($ank['id']).' ('.vremja($post['time']).')<br />';
	echo '</div>';
	echo '</div>';
	
	
	
	$style = "min-height:50px;";
	
	echo '<div class="n2" style="'.$style.'">';
		echo output_text($post['msg']).'<br />';
	echo '</div>';
	
	echo '</div>';
	
	if (isset($_GET['act']))
	{
		echo '<div class="main">';
		echo '<img src="/style/icons/ok.gif" alt="*"> <a href="?post='.$post['id'].'&amp;page='.$page.'&amp;ok">Готово</a> | <a href="'.htmlspecialchars($_SERVER['REQUEST_URI']).'">Еще вариант</a>';
		echo '</div>';
	}

/**
* 
* @var / Помидор
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=pomidor"><img src="img/tomate.png"/> Кинуть помидор</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Краски
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=kraski"><img src="img/kraski.png"/> Заляпать краской</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Поцелуйчик
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=kiss"><img src="img/kiss.png"/> Оставить поцелуй</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Сердечки
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=serdce"><img src="img/serdce.png"/> Сердечки</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Выстел
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=puli"><img src="img/puli.png"/> Пальнуть из нагана</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Пчела
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=pchel"><img src="img/pchel.png"/> Посадить пчёлку</a> 20 баллов';
echo '</div>';

/**
* 
* @var / Скелет
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=scelet"><img src="img/scelet.png"/> Оставить кости</a> 20 баллов';
echo '</div>';
/**
* 
* @var / Cлед динозавра
* 
*/
echo '<div class="nav1">';
echo '<a href="?post=' . $post['id'] . '&amp;page=' . intval($_GET['page']) . '&amp;act=dino"><img src="img/dino.png"/> След динозавра</a> 20 баллов';
echo '</div>';

echo '<div class="foot">';
echo '<img src="/style/icons/str2.gif" alt="*"> <a href="index.php">Гостевая</a><br />';
echo '</div>';
}else{ echo "<div class='err'> У вас нет баллов даже на один ляп нужно как минимум 20 баллов</div>";echo '<br/><img src="/style/icons/guest.png"/> <a href="index.php">Гостевая</a><br />';}
include_once '../sys/inc/tfoot.php';
?>