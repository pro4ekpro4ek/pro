<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
$id=NULL;
if (isset($_GET['id']))$id=intval($_GET['id']);
if (isset($_GET['edit']))$id=intval($_GET['edit']);
$komm=mysql_fetch_assoc(mysql_query("SELECT * FROM `guest` WHERE `id` = '".$id."' LIMIT 1"));
if (isset($_GET['id'])){ $set['title']=' Приватно'; }else{ $set['title']='Редактирование сообщения'; }
include_once '../sys/inc/thead.php';
$otv=NULL;

$otvet=get_user($komm['id_user']);

$otv='[b]'.$otvet['nick'].':[/b] ';
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `id` = '".$id."' LIMIT 1",$db), 0)==0){header("Location: index.php?".SID);exit;}
if (isset($_POST['save']) && isset($user))
{
$msg=$_POST['msg'];
if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);

$mat=antimat($msg);
if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;
if (strlen2($msg)>1024){$err='Сообщение слишком длинное';}
elseif (strlen2($msg)<2){$err='Короткое сообщение';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `id_user` = '$user[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}
elseif(!isset($err)){
mysql_query("INSERT INTO `guest` (`id_user`, `time`, `msg`, `privat`) values('$user[id]', '$time', '".my_esc($msg)."', '".$komm['id_user']."')");
mysql_query("UPDATE `user` SET `balls` = '".($user['balls']+1)."' WHERE `id` = '$user[id]' LIMIT 1");
if (isset($_POST['msg'])){
$mail=''.$user['nick'].' написал Вам в беседке шепотом.';
mysql_query("INSERT INTO `jurnal` (`id_user`, `id_kont`, `msg`, `time`) values('0', '".$komm['id_user']."', '".$mail."', '$time')");
$msg="test";
mysql_query("INSERT INTO `guest` (`id_user`, `time`, `msg`) values('2', '$ank[id]', '$time', '$msg2')");
msg('Ваш комментарий успешно принят');
header("Location: index.php");
}
}
}
if (isset($_POST['sav'])){
if (isset($user) && ($user['id']==$otvet['id']) && ($komm['time']>=(time()-600) || isset($user) && ($user['level']>=$otvet['level']))){
$msge=my_esc($_POST['msge']);
$mat=antimat($msge);
if ($mat)$err='В тексте обнаружен мат: '.$mat.'';
if (strlen2($msge)>1024)$err='Сообщение слишком длинное!';
if (strlen2($msge)<2)$err='Сообщение слишком короткое!';
}else{
$err='Вы не можете редактировать сообщениe!';
}
if (!isset($err)){
msg('Успешно изменено');
mysql_query("UPDATE `guest` SET `msg` = '".$msge."' WHERE `id` = '$id'");
header("Location: index.php");
}
}


err();
title();

aut(); // форма авторизации
echo "<div class='p_m'>\n";
echo ''.output_text($komm['msg']).'';
echo "</div>\n";
if (!isset($_GET['edit'])){
if (isset($user))
{
echo '<form method="post" action="?id='.intval($_GET['id']).'"><br/><input type="text" name="msg" value="'.$otv.'"/><input type="submit" value="Отправить" name="save"/></form>';
}
}else{
if (isset($user) && ($user['id']==$otvet['id']) && ($komm['time']>=time()-600) || isset($user) && ($user['level']>=$otvet['level'])){
echo "<form method='post' action='?edit=".$id."'><br/><input type='text' name='msge' value='$komm[msg]' /><br/><input type='submit' value='Применить' name='sav'/></form>";
}
}
include_once '../sys/inc/tfoot.php';
?>