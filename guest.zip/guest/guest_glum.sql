CREATE TABLE `guest_glum` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`id_user` int(11) NOT NULL,
`time` int(11) NOT NULL,
`dir` varchar(32) NOT NULL,
`img` varchar(32) NOT NULL,
`margin_left` int(11) NOT NULL,
`id_post` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;