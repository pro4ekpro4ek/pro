<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
$id=NULL;
if (isset($_GET['id']))$id=intval($_GET['id']);
if (isset($_GET['edit']))$id=intval($_GET['edit']);
$komm=mysql_fetch_assoc(mysql_query("SELECT * FROM `guest` WHERE `id` = '".$id."' LIMIT 1"));
$set['title']='Ответ';
include_once '../sys/inc/thead.php';
title();
$otvet=get_user($komm['id_user']);
$otv=''.$otvet['nick'].', ';
if (isset($_GET['id']))
{
$post =
mysql_fetch_array(mysql_query("SELECT * FROM `guest` WHERE `id`='".intval($_GET['id'])."' LIMIT 1"));
$ank = mysql_fetch_array(mysql_query("SELECT * FROM `user` WHERE `id`=$post[id_user] LIMIT 1"));
if (isset($_POST['msg']))
{
$msg = my_esc($_POST['msg']);
if (strlen2($msg)>1024){$err='Извините, но Ваш ответ слишком длинный';}
elseif (strlen2($msg)<2){$err='Извините, но Ваш ответ слишком короткий';}
else{
$msg=mysql_escape_string($msg);
mysql_query("INSERT INTO `guest` (`id_user`, `time`, `msg`) VALUES ('$user[id]', '$time', '$msg')");
mysql_query("UPDATE `user` SET `guest` '".($user['guest']+1)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `jurnal` (`id_user`, `id_kont`, `msg`, `time`) values('0', '$ank[id]', '[b][url=/info.php?id=$user[id]] $user[nick] [/url][/b] Ответил(а) на сообщение в [b] [url=/guest.php]гостевой книге[/url] [/b]', '$time')");
mysql_query("UPDATE `user` SET `balls` = '".($user['balls']+1)."' WHERE `id` = '$user[id]' LIMIT 1");
header("Location: index.php?otvet_ok&".SID);
exit;
}
}
aut();
if(isset($user)){
echo "<div class='str'>\n";
echo "<a href='".$_SERVER [REQUEST_URI]."'>Обновить</a> | ";
echo "<a href='/smiles/'>Смайлики</a> | ";
echo "<a href='/bb-code.php'>Теги</a><br />\n";
echo "</div>\n";
echo "<div class='p_t'>\n";
echo '<form method="post" action="otvet.php?id='.$post['id'].'">';
echo '<input type="post" action="?id='.intval($_GET['id']).'" name="msg" value="'.$otv.'"/><br/><input type="submit" value="Отправить ответ"/><br/>';
if (isset($user) && $user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit\" value=\"1\" /> Транслит</label><br />\n";
echo '</form>';
echo "</div>\n";
};
}else{
echo '<div class="msg">Содержимое доступно только для авторизированых пользователей</div>';
};
include_once '../sys/inc/tfoot.php';
?>