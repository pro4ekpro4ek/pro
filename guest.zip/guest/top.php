<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
$set['title']='Рейтинг гостевой'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();
aut();
{
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `guest` > '0'"), 0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `user` WHERE `guest` > '0' ORDER BY `guest` DESC LIMIT $start, $set[p_str]");
if ($k_post==null)
{
echo "Нет ((\n";
}
while ($ank = mysql_fetch_array($q))
{

echo "<div class='p_m'>";
avatar($ank['id']);
echo "".online($ank['id'])." ";
echo " <a href='/info.php?id=$ank[id]'><b>$ank[nick]</b></a> ";
echo "<br/>";
if ($ank['pol']==1)
echo "(Муж)";
else
echo "(Жен)";

if ($ank['ank_d_r']!=NULL && $ank['ank_m_r']!=NULL && $ank['ank_g_r']!=NULL){
$ank['ank_age']=date("Y")-$ank['ank_g_r'];
if (date("n")<$ank['ank_m_r'])$ank['ank_age']=$ank['ank_age']-1;
elseif (date("n")==$ank['ank_m_r']&& date("j")<$ank['ank_d_r'])$ank['ank_age']=$ank['ank_age']-1;
echo ",$ank[ank_age] лет";
}
if ($ank['ank_city']!=NULL)echo ",$ank[ank_city]";
echo "<br/>";
echo "<img src='/garem/img/rating.png' alt=''/>оставил(а) <strong>".$ank['guest']."</strong> сообщений</div>\n";

}
if ($k_page>1)str("?",$k_page,$page);
}
echo "<a href='index.php'>Назад </a></br>";
echo "</div>";
include_once '../sys/inc/tfoot.php';
?>