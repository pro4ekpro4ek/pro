CREATE TABLE `guest` (
`id` int(11) NOT NULL auto_increment,
`id_user` int(11) NOT NULL default '0',
`time` int(11) NOT NULL,
`msg` varchar(1024) character set utf8 collate utf8_unicode_ci default NULL,
`id_file` int(11) NOT NULL,
`file` varchar(32) NOT NULL,
`ras` varchar(32) NOT NULL,
`privat` int(11) default '0',
PRIMARY KEY (`id`),
KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;


CREATE TABLE `guest_files` (
`id` int(11) NOT NULL auto_increment,
`id_post` int(11) NOT NULL,
`name` varchar(64) default NULL,
`ras` varchar(32) NOT NULL,
`size` int(11) NOT NULL,
`type` varchar(32) NOT NULL,
`count` int(11) NOT NULL default '0',
`rating` int(11) NOT NULL default '0',
PRIMARY KEY (`id`),
KEY `id_post` (`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE `guest_glum` (
`id` int(11) NOT NULL auto_increment,
`id_user` int(11) NOT NULL,
`time` int(11) NOT NULL,
`dir` varchar(32) NOT NULL,
`img` varchar(32) NOT NULL,
`margin_left` int(11) NOT NULL,
`id_post` int(11) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;


CREATE TABLE `guest_like` (
`id` int(11) NOT NULL auto_increment,
`id_post` int(11) NOT NULL,
`id_user` int(11) NOT NULL,
`like` int(11) default '0',
`likes` int(11) default '0',
PRIMARY KEY (`id`,`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
ALTER TABLE `user` ADD `guest` int(11) DEFAULT '0' ;