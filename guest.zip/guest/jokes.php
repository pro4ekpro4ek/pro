<?php

define('H', $_SERVER['DOCUMENT_ROOT'].'/');

require H.'sys/inc/start.php';
require H.'sys/inc/compress.php';
require H.'sys/inc/sess.php';
require H.'sys/inc/settings.php';
require H.'sys/inc/db_connect.php';
require H.'sys/inc/ipua.php';
require H.'sys/inc/fnc.php';
require H.'sys/inc/user.php';

$set['title'] = 'Закляни друзей';

include H.'sys/inc/thead.php';

title();
aut();
only_reg();

if (isset($_GET['help']))
{

{
mysql_query("update `user` set `joke_time` = ".time()." where `id` = ". intval($_GET['help']));
exit(header('location: /info.php?id='.$_GET['help']));
}
}

if
(
! isset($_GET['id']) ||
! is_numeric($_GET['id']) ||
! isset($_GET['sel']) ||
! file_exists('data/'.$_GET['sel'].'.joke'))
{
?>
<div class="err">
Системе не удалось выявить нужное вам действие
</div>
<?php
include H.'sys/inc/tfoot.php';
}
$joke = unserialize(file_get_contents('data/'.$_GET['sel'].'.joke'));

if ($joke['balls'] > $user['balls'])
{
?>
<div class="err">
Недостаточно баллов для заклинания
</div>
<?php
include H.'sys/inc/tfoot.php';
}

mysql_query('update `user` set `balls`=`balls`-'.$joke['balls'].' where `id`='.$user['id']);

mysql_query('update `user` set `joke_name`="' . $joke['name'] . '", `joke_time` = "' . (time() + $joke['time']) . '" where `id`='.intval($_GET['id']));

mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) values('".intval($_GET['id'])."', '".intval($_GET['id'])."', '$user[nick] применил на Вас заклятие \"".$joke['rus_name']."\". Действие которого 2 часа удачи', '$time')");

$err[] = '- ' . $joke['balls'].' баллов';

err();

msg('Вы успешно использовали заклинание: "'.$joke['rus_name'].'"');

?>
<a href="index.php">
<div class="p_m">
&larr; Гостевая
</div>
</a>
<?php

include H.'sys/inc/tfoot.php';