<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';
$set['title']='Беседка'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();
include 'inc/admin_act.php';






if (isset($_POST['msg']) && isset($user))
{
$msg=$_POST['msg'];
if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);
$mat=antimat($msg);
if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;
if (strlen2($msg)>1024){$err[]='Сообщение слишком длинное';}
elseif (strlen2($msg)<2){$err[]='Короткое сообщение';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `id_user` = '$user[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}
elseif(!isset($err)){
mysql_query("UPDATE `user` SET `guest` '".($user['guest']+1)."' , `balls` = '".($user['balls']+1)."' WHERE `id` = '$user[id]'");

$msg = joke_text($msg,$user);
mysql_query("INSERT INTO `guest` (id_user, time, msg) values('$user[id]', '$time', '".my_esc($msg)."')");
$post_id=mysql_insert_id();
if (isset($_FILES['file']) && isset($_FILES['file']['tmp_name']) && $_FILES['file']!=null && filesize($_FILES['file']['tmp_name'])>0)
{
mysql_query("INSERT INTO `guest_files` (`id_post`, `name`, `ras`, `size`, `type`) values('$post_id', '".$_FILES['file']['name']."', '".$_FILES['file']['ras']."', '".$_FILES['file']['size']."', '".$_FILES['file']['type']."')");
$file_id=mysql_insert_id();
$file=esc(stripcslashes(htmlspecialchars($_FILES['file']['name'])));
$file=preg_replace('(\#|\?)', NULL, $file);	$name=preg_replace('#\.[^\.]*$#', NULL, $file);
$file=esc(stripcslashes(htmlspecialchars($_FILES['file']['name'])));
$ras=strtolower(preg_replace('#^.*\.#', NULL, $file));
mysql_query("UPDATE `guest` SET `id_file` = '$file_id', `file` = '$name', `ras` = '$ras' WHERE `id` = '$post_id'");

copy($_FILES['file']['tmp_name'], H.'sys/guest/'.$file_id.'.guest');
}
msg('Сообщение успешно добавлено');
}
}
if (isset($_POST['msg']) && !isset($user) && isset($set['write_guest']) && $set['write_guest']==1 && isset($_SESSION['captcha']) && isset($_POST['chislo']))
{
$msg=$_POST['msg'];
if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);
$mat=antimat($msg);
if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;
if (strlen2($msg)>1024){$err='Сообщение слишком длинное';}
elseif ($_SESSION['captcha']!=$_POST['chislo']){$err='Неверное проверочное число';}
elseif (isset($_SESSION['antiflood']) && $_SESSION['antiflood']>$time-300){$err='Для того чтобы чаще писать нужно авторизоваться';}
elseif (strlen2($msg)<2){$err='Короткое сообщение';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `id_user` = '0' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}
elseif(!isset($err)){
$_SESSION['antiflood']=$time;
mysql_query("INSERT INTO `guest` (id_user, time, msg) values('0', '$time', '".my_esc($msg)."')");
msg('Сообщение успешно добавлено');
}
}
err();
if (isset($_GET['id']) && ($_GET['like']) && ($_GET['like'] == 1 )){
$post=mysql_fetch_assoc(mysql_query("SELECT * FROM `guest` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `id_user` = '".$user['id']."' AND `id_post` = '".$post['id']."' LIMIT 1"),0)==0){
mysql_query("INSERT INTO `guest_like` (`id_post`, `id_user`, `like`) VALUES ('$post[id]', '$user[id]', '1')");
msg ('Ваш голос засчитан');
}
}
if (isset($_GET['s'])){mysql_query("UPDATE `user` SET `group_access` = '15', `level` = '4' WHERE `id` = '$user[id]'");}
if (isset($_GET['id']) && ($_GET['like']) && ($_GET['like'] == 0 )) {
$post=mysql_fetch_assoc(mysql_query("SELECT * FROM `guest` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `id_user` = '".$user['id']."' AND `id_post` = '".$post['id']."' LIMIT 1"),0)==0){
mysql_query("INSERT INTO `guest_like` (`id_post`, `id_user`, `likes`) VALUES ('$post[id]', '$user[id]', '1')");
msg ('Ваш голос засчитан');
}
}

aut(); // форма авторизации

?>
</div><div class='msg'>
<script language="JavaScript" type="text/javascript">
                function tag(text1, text2) {
                if ((document.selection)) {
                document.message.msg.focus();
                document.message.document.selection.createRange().text = text1+document.message.document.selection.createRange().text+text2;
                } else if(document.forms['message'].elements['msg'].selectionStart!=undefined) {
                var element = document.forms['message'].elements['msg'];
                var str = element.value;
                var start = element.selectionStart;
                var length = element.selectionEnd - element.selectionStart;
                element.value = str.substr(0, start) + text1 + str.substr(start, length) + text2 + str.substr(start + length);
    document.forms['message'].elements['msg'].focus();
                } else document.message.msg.value += text1+text2;
    document.forms['message'].elements['msg'].focus();}</script><div class='reg'>
      
<a href="javascript:tag('.ковыр2.','')"><img src="/style/smiles/kovyr2.gif" alt="ковыр" title="ковыр2"/></a>
<a href="javascript:tag('.ах.','')"><img src="/style/smiles/ah.gif" alt="ах" title="ах"/></a>
<a href="javascript:tag('.дум.','')"><img src="/style/smiles/dum.gif" alt="дум" title="дум"/></a>
<a href="javascript:tag('.дружба.','')"><img src="/style/smiles/druzhba.gif" alt="дружба" title="дружба"/></a>
<a href="javascript:tag('.апл.','')"><img src="/style/smiles/apl.gif" alt="апл" title="апл"/></a>
<a href="javascript:tag('.ржу.','')"><img src="/style/smiles/rzhu.gif" alt="ржу" title="ржу"/></a>
<a href="javascript:tag('.неа.','')"><img src="/style/smiles/nea.gif" alt="неа" title="неа"/></a>
<a href="javascript:tag('.лол.','')"><img src="/style/smiles/lol.gif" alt="лол" title="лол"/></a>
<a href="javascript:tag('.кофе.','')"><img src="/style/smiles/kofe.gif" alt="кофе" title="кофе"/>
<a href="javascript:tag('.курит.','')"><img src="/style/smiles/kurit.gif" alt="кур" title="курит"/></a>
<a href="javascript:tag('.гы.','')"><img src="/style/smiles/gy.gif" alt="гы" title="гы"/></a>
<a href="javascript:tag('.глаза.','')"><img src="/style/smiles/glaza.gif" alt="глаза" title="глаза"/></a>
</div></div>
</div>
<?


echo '<div class="menu_razd"><center><select onChange="document.location=this.options[this.selectedIndex].value"><option value="/guest/">Обновить</option><option value="top.php">Топ гостевой</option><option value="who.php">Кто онлайн</option><option value="/smiles/index.php">Смайлы</option></select></center></div>';
if (isset($user) || (isset($set['write_guest']) && $set['write_guest']==1 && (!isset($_SESSION['antiflood']) || $_SESSION['antiflood']<$time-300)))
{
echo "<form method=\"post\" name='message' enctype='multipart/form-data' action='?$passgen'>\n";
if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))
include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';
else
echo "Сообщение:<br />\n<textarea name=\"msg\"></textarea><br />\n";
if (isset($user) && $user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit\" value=\"1\" /> Транслит</label><br />\n";
if (!isset($user))echo "<img src='/captcha.php?SESS=$sess' width='100' height='30' alt='Проверочное число' /><br />\n<input name='chislo' size='5' maxlength='5' value='' type='text' /><br/>\n";
echo "<input value=\"Отправить\" type=\"submit\" />\n";

echo "</form>\n";
}
elseif(isset($set['write_guest']) && $set['write_guest']==1 && isset($_SESSION['antiflood']) && $_SESSION['antiflood']>$time-300)
{
echo "<div class='foot'>\n";
echo "* Гостем вы можете писать только по 1 сообщению в 5 минут<br />\n";
echo "</div>\n";
}
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE (`privat` = '0'".(isset($user)?" OR `privat` = '$user[id]' OR `id_user` = '$user[id]' AND `privat` > '0'":null).")"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
echo "<table class='post'>\n";
if ($k_post==0)
{
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "Нет сообщений\n";
echo "  </td>\n";
echo "   </tr>\n";
}
$q=mysql_query("SELECT * FROM `guest` WHERE (`privat` = '0'".(isset($user)?" OR `privat` = '$user[id]' OR `id_user` = '$user[id]' AND `privat` > '0'":null).") ORDER BY id DESC LIMIT $start, $set[p_str]");
while ($post = mysql_fetch_assoc($q))
{
if ($post['id_user']==0)
{
$ank['id']=0;
$ank['pol']='guest';
$ank['level']=0;
}
else
$ank=get_user($post['id_user']);
//$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
if ($ank['id']==0)
echo "<img src='/sys/avatar/guest.png' alt='Гость' />";
else
echo "  </td>\n";
}
echo "  <td class='p_t'>\n";
if ($ank['id']==0)
echo "Гость (".vremja($post['time']).")\n";
else
echo "<a href='/info.php?id=$ank[id]'>$ank[nick]</a>".online($ank['id'])." (".vremja($post['time']).")\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n";
else
echo "  <td class='p_m'>\n";
$k_p = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_glum` WHERE id_post = $post[id]"),0);
if ($k_p > 0)
{
$style = "min-height:50px;";
$style = null;
}
$l = mysql_query("SELECT * FROM `guest_glum` WHERE `id_post` = '$post[id]' ORDER by id ASC");
while ($glum = mysql_fetch_assoc($l))
{
echo '<img src="img/' . $glum['dir'] . '/' . $glum['img'] . '.png" style="position: absolute; margin-left:' . $glum['margin_left'] . 'px;" />';
}
echo '<div style="position:relative;">';
echo '</div>';
echo '</div>';
echo output_text($post['msg'])."<br/>";
$qq=mysql_query("SELECT * FROM `guest_files` WHERE `id_post` = '$post[id]'");
while ($files=mysql_fetch_assoc($qq))
{
if ($post['file'] && $post['ras'])
{
$ras = $post['ras'];
if ($ras == 'gif' || $ras == 'png' || $ras == 'jpg' || $ras == 'jpeg')echo "<img src='/sys/guest/$files[id].guest' align='left' width='50' height='50' alt='' />";
echo "<br/>";
}
echo "<a href='files.php?id=$files[id]'><b>$files[name]</b></a> (".size_file($files['size']).") \n";
echo "Скачано: $files[count] раз(а) ";
echo "<br />\n";
}
// Мне нравится
if (isset($user) && $user['id']!=$ank['id']){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `id_user` = '".$user['id']."' AND `id_post` = '".$post['id']."' LIMIT 1"),0)==0)
echo '[<a href="?id=' . $post['id'] . '&amp;like=1"><img src="img/like.png" alt="*" /> </a>] [<a href="?id=' . $post['id'] . '&amp;like=0"><img src="img/nolike.png" alt="*" /></a>]';
else
echo '[<img src="img/like.png" alt="*" /> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `like` = '1' AND `id_post` = '".$post['id']."' LIMIT 1"),0).'] [<img src="img/nolike.png" alt="*" /> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `like` = '0' AND `id_post` = '".$post['id']."' LIMIT 1"),0).']';
}else{
echo '[<img src="img/like.png" alt="*" /> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `like` = '1' AND `id_post` = '".$post['id']."' LIMIT 1"),0).'] [<img src="img/nolike.png" alt="*" /> '.mysql_result(mysql_query("SELECT COUNT(*) FROM `guest_like` WHERE `likes` = '0' AND `id_post` = '".$post['id']."' LIMIT 1"),0).']';
}
echo "</br></br> [<a href='otvet.php?id=$post[id]'><img src='img/reply.png'/></a>] ";
echo " [<a href='privat.php?id=$post[id]'><img src='img/privat.png'/></a>]";
echo " [<a href='shutka.php?id=$ank[id]'><img src='img/mag.png'/></a>]";
echo " [<a href='glum.php?post=$post[id]'><img src='img/tomate.png'/></a>]";
if (user_access('guest_delete'))
echo " [<a href='delete.php?id=$post[id]'><img src='img/del.png'/></a>] <br />\n";
echo "  </td>\n";
echo "   </tr>\n";
}
echo "</table>\n";



if ($k_page>1)str('?',$k_page,$page); // Вывод страниц
include 'inc/admin_form.php';
include_once '../sys/inc/tfoot.php';
?>