DROP TABLE IF EXISTS `guest`;

CREATE TABLE `guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `privat` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guest_files`;

CREATE TABLE `guest_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `ras` varchar(32) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guest_glum`;

CREATE TABLE `guest_glum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `dir` varchar(32) NOT NULL,
  `img` varchar(32) NOT NULL,
  `margin_left` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guest_like`;

CREATE TABLE `guest_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `like` int(11) DEFAULT '0',
  `likes` int(11) DEFAULT '0',
  PRIMARY KEY (`id`,`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guest_otv`;

CREATE TABLE `guest_otv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `id_msg` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `guests`;

CREATE TABLE `guests` (
  `ip` bigint(20) NOT NULL,
  `ua` varchar(32) NOT NULL,
  `date_aut` int(11) NOT NULL,
  `date_last` int(11) NOT NULL,
  `url` varchar(64) NOT NULL,
  `pereh` int(11) NOT NULL DEFAULT '0',
  KEY `ip_2` (`ip`,`ua`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `ingame1`;

CREATE TABLE `ingame1` (
  `gamer_id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `gamer_act` varchar(50) NOT NULL,
  `id_in_game` int(11) NOT NULL,
  `dvote` int(11) NOT NULL,
  `wholin` int(11) NOT NULL,
  `onl` int(12) NOT NULL,
  `state` tinyint(1) NOT NULL,
  PRIMARY KEY (`gamer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `ingame2`;

CREATE TABLE `ingame2` (
  `gamer_id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `gamer_act` varchar(50) NOT NULL,
  `id_in_game` int(11) NOT NULL,
  `dvote` int(11) NOT NULL,
  `wholin` int(11) NOT NULL,
  `onl` int(12) NOT NULL,
  `state` tinyint(1) NOT NULL,
  PRIMARY KEY (`gamer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `ingame3`;

CREATE TABLE `ingame3` (
  `gamer_id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `gamer_act` varchar(50) NOT NULL,
  `id_in_game` int(11) NOT NULL,
  `dvote` int(11) NOT NULL,
  `wholin` int(11) NOT NULL,
  `onl` int(12) NOT NULL,
  `state` tinyint(1) NOT NULL,
  PRIMARY KEY (`gamer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




