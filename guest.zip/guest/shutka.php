<?php

define('H', $_SERVER['DOCUMENT_ROOT'].'/');

require H.'sys/inc/start.php';
require H.'sys/inc/compress.php';
require H.'sys/inc/sess.php';
require H.'sys/inc/settings.php';
require H.'sys/inc/db_connect.php';
require H.'sys/inc/ipua.php';
require H.'sys/inc/fnc.php';
require H.'sys/inc/user.php';

$set['title'] = 'Закляни друзей';

include H.'sys/inc/thead.php';

title();
aut();
only_reg();


//$data = array('name' => 'retranslit', 'rus_name' => 'Ретранслит', 'time' => 3600, 'status' => 'on', 'balls' => 500, 'desc' => 'После заклятия, написанные пользователем русские буквы будут заменены на английские', 'img' => 'retranslit');
//file_put_contents('data/retranslit.joke',serialize($data));

if
(
! isset($_GET['id']) ||
! is_numeric($_GET['id'])
)
echo '<table class="post">';

$jokes = glob('data/*.joke');
foreach ($jokes as $jokes)
{
$joke = unserialize(file_get_contents($jokes));

?>
<tr>
<td class="p_m" width="5%">
<img src="img/<?=$joke['img']?>.png"/>
</td>

<td class="p_m">
Название:

<?php
if ($joke['status'] == 'on')
{
?>
<a href="<?='jokes.php?id='.intval($_GET['id']).'&amp;sel='.$joke['name']?>">
<?
}

echo $joke['rus_name'];

if ($joke['status'] == 'on')echo '</a>';
?>
<br />

<?php

if ($joke['status'] == 'on')
{
?>

Статус:
<span class="on">
включен
</span>

<?php
}
else
{
?>
Статус:
<span class="off">
отключен
</span>

<?
}
echo
'<br />Действие(в секундах): '.$joke['time'],
'<br />Стоимость(в баллах): '.$joke['balls'],
'<br />Описание: '.$joke['desc'],
'</td></tr>';
}

echo '</table>';

include H.'sys/inc/tfoot.php';
?>
